#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-cpu --algorithm circcash --pool stratum-eu.rplant.xyz:7050 --wallet circcash-wallet-here
