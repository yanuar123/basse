#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm yespower2b --pool stratum-ru.rplant.xyz:7022 --wallet MiMsdYxQ7rZBrWraib8C2MT27ESWdAKp4A
