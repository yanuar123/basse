#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm minotaurx --pool stratum-eu.rplant.xyz:7063 --wallet CNBfT7qDwBWvsTb2FLk1CXKojL2odVaJGj
